i = 1


classname = []
classnumber = []
name = []
path = 'classmember.txt'

with open(path,encoding='utf-8') as f:
    for line in f.readlines():
        s = line.split(' ')
        classname.append(s[0])
        classnumber.append(s[1])
        name.append(s[2])


print("查詢資料系統\n")

while i != 0:
    membernumber = input('輸入學號 : ')
    score = input('輸入成績 : ')
    score = str(score)
    for line in range(0,63):
        if(membernumber in classnumber[line]):
            print("查詢結果:\n"+"人物資料: "+classname[line]+" "+classnumber[line]+" "+name[line]+"分數: "+score)

    i = input('是否繼續執行(輸入0為終止) : ')
    i = int(i)
print("程式已終止")